import React, { Component } from "react";
import PageCustom from "../../components/PageCustom";

class DashboardPage extends Component {
  
  render() {
    return <PageCustom title="Dashboard"></PageCustom>;
  }
}

export default DashboardPage;
